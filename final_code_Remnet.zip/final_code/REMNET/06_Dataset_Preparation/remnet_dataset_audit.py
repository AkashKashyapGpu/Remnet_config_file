"""REMNET dataset SHA-256 audit and deterministic leakage-controlled split.

Usage: python remnet_dataset_audit.py /path/to/original_dataset /path/to/output

Original directory must contain Training/<class>/* and Testing/<class>/* .
No input image files are modified.
"""
from __future__ import annotations
import csv, hashlib, json, random, sys
from collections import defaultdict, Counter
from pathlib import Path

EXTS={'.jpg','.jpeg','.png','.bmp','.webp'}
SPLIT_SEED=2026
VAL_FRACTION=0.20

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def scan(root, name):
    arr=[]
    for p in sorted((root/name).rglob('*')):
        if p.is_file() and p.suffix.lower() in EXTS:
            arr.append({'path':p.relative_to(root).as_posix(), 'label':p.parent.name, 'original_partition':name, 'sha256':sha(p)})
    return arr

def write_csv(path, rows, columns):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=columns,extrasaction='ignore');w.writeheader();w.writerows(rows)

def build(root, output):
    root=Path(root).resolve(); output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    if not (root/'Training').is_dir() or not (root/'Testing').is_dir():
        raise FileNotFoundError(f'Missing Training/Testing under {root}')
    original_train=scan(root,'Training');original_test=scan(root,'Testing')
    if not original_train or not original_test:raise RuntimeError('No dataset images found')
    train_classes={r['label'] for r in original_train};test_classes={r['label'] for r in original_test}
    if train_classes!=test_classes:raise RuntimeError(f'Class mismatch {train_classes}^{test_classes}')
    train_hashes=defaultdict(list)
    for r in original_train:train_hashes[r['sha256']].append(r)
    excluded=[];clean_train=[]
    for h,items in sorted(train_hashes.items()):
        items=sorted(items,key=lambda r:r['path'])
        if len({r['label'] for r in items})!=1:
            excluded.extend([{**r,'reason':'conflicting_labels_within_training','related_files':' | '.join(x['path'] for x in items)} for r in items])
        else:
            clean_train.append(items[0])
            excluded.extend([{**r,'reason':'same_label_duplicate_within_training','related_files':items[0]['path']} for r in items[1:]])
    clean_train_hashes={r['sha256'] for r in original_train} # even ambiguous hashes disallowed in test
    kept_test=[];seen_test={}
    for r in original_test:
        h=r['sha256']
        if h in clean_train_hashes:
            excluded.append({**r,'reason':'exact_cross_split_duplicate','related_files':' | '.join(x['path'] for x in train_hashes[h])})
        elif h in seen_test:
            excluded.append({**r,'reason':'exact_duplicate_within_testing','related_files':seen_test[h]['path']})
        else:
            kept_test.append(r);seen_test[h]=r
    by_class=defaultdict(list)
    for r in clean_train:by_class[r['label']].append(r)
    validation=[];training=[]
    for label,items in sorted(by_class.items()):
        items=sorted(items,key=lambda r:r['path'])
        rng=random.Random(f'{SPLIT_SEED}:{label}')
        rng.shuffle(items)
        nval=max(1,min(len(items)-1,round(len(items)*VAL_FRACTION)))
        validation+=items[:nval];training+=items[nval:]
    manifest=sorted(({**r,'final_partition':final} for final, rows in [('train',training),('validation',validation),('test',kept_test)] for r in rows),key=lambda r:(r['final_partition'],r['label'],r['path']))
    assert len({r['path'] for r in manifest})==len(manifest)
    for partA in ['train','validation','test']:
        for partB in ['train','validation','test']:
            if partA>=partB:continue
            assert not ({r['sha256'] for r in manifest if r['final_partition']==partA} & {r['sha256'] for r in manifest if r['final_partition']==partB}), (partA,partB)
    columns=['path','label','original_partition','final_partition','sha256']
    write_csv(output/'REMNET_final_dataset_manifest.csv',manifest,columns)
    write_csv(output/'REMNET_excluded_files_audit.csv',sorted(excluded,key=lambda r:r['path']),['path','label','original_partition','sha256','reason','related_files'])
    counts={p:dict(sorted(Counter(r['label'] for r in manifest if r['final_partition']==p).items())) for p in ['train','validation','test']}
    report={'original_training':len(original_train),'original_testing':len(original_test),'original_total':len(original_train)+len(original_test), 'final_train':len(training),'final_validation':len(validation),'final_test':len(kept_test),'final_total':len(manifest), 'excluded_total':len(excluded), 'exclusion_reasons':dict(Counter(r['reason'] for r in excluded)),'class_counts':counts,'stratification_seed':SPLIT_SEED,'validation_fraction_requested':VAL_FRACTION,'policy':'Remove all conflicting-label training groups; retain one of each same-label training hash; remove test images matching any original train hash; create class-stratified validation split. No perceptual-near-duplicate screening applied.'}
    (output/'REMNET_split_summary.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
    print(json.dumps(report,indent=2))
    return report

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: python remnet_dataset_audit.py SOURCE_DATASET_ROOT OUTPUT_DIR')
    build(sys.argv[1],sys.argv[2])
