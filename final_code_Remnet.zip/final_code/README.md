# REMNET — Waste Image Classification, External Validation, and Sustainability

Research code and archived outputs for **REMNET** (ensemble of MobileNetV2, ResNet50, and EfficientNet-Lite0), including original-dataset classification, **separately run** CodeCarbon sustainability experiments, and frozen-model zero-shot evaluation on two additional image collections. The repository contains 29 Jupyter notebooks, one standalone dataset-audit Python module, generated CSVs and CodeCarbon logs. It does **not** bundle the source image datasets or the trained `.pt` checkpoint files required by external-validation notebooks.

> **Critical experimental distinction.** The original **classification** and **sustainability** workflows are **separate training/inference experiments**, not two measurements of exactly the same training execution. The recorded classification accuracies must not be combined with independently monitored energy records as though the model weights, execution duration, and checkpoint identities were paired. In particular, REMNET's classification and sustainability constituent checkpoint sets differ; the standalone ResNet50 implementations also differ (`torchvision` versus `timm`). Energy/accuracy or carbon/accuracy quotients assembled from their separate means are derived cross-run indicators, **not validated checkpoint-matched efficiency estimates**. Some D3 sustainability diagnostic accuracies also differ from classification results. Do not overwrite or silently reconcile those values.

## Directory map

```text
final_code/
├── README.md                        # this guide
├── requirements.txt                 # observed environment pins and documented range-only extras
├── config.yaml                      # reference configuration; not consumed automatically by notebooks
├── LICENSE                          # current code-rights notice; datasets have separate licenses
├── REMNET/
│   ├── 01_Classification_Implementation/          # original-dataset model training and evaluation
│   ├── 02_Energy_and_Carbon_Measurement/         # independent CodeCarbon experiments
│   ├── 03_Statistical_Analysis/                   # Stage 2 comparison notebooks
│   ├── 04_Classification_Results/                 # per-seed original classification CSVs
│   ├── 05_Computational_Complexity/               # GFLOPs and no-checkpoint throughput benchmark
│   └── 06_Dataset_Preparation/                    # remnet_dataset_audit.py and split manifests
├── 09_Sustainability_Results/                    # source data and original CodeCarbon logs
├── Garbage Classification V2 external validation/07_Garbage_Classification_V2/
│   ├── Dataset verification/                      # source audit; 4,931-image locked cohort
│   ├── Classification implementation/             # frozen-model external tests and statistical test
│   └── Classification results/
└── RealWaste external validation/08_RealWaste/
    ├── Dataset verification/                      # source audit; 3,497-image locked cohort
    ├── Classification implementation/             # frozen-model external tests and statistical test
    ├── Classification results/
    └── Sustainability implementation/             # separately monitored D3 inference
```

## Datasets and download links

| Role | Source and download | Dataset path used in the notebooks | Restrictions and caveats |
|---|---|---|---|
| D1 — original development/test | [Garbage Classification Image Dataset (Kaggle)](https://www.kaggle.com/datasets/saumyamohandas/garbage-classification-image-dataset) | `/kaggle/input/datasets/saumyamohandas/garbage-classification-image-dataset` (some notebooks also accept `/kaggle/input/garbage-classification-image-dataset`) | Six material classes; attach the dataset in Kaggle. Notebook-saved original-test results refer to **463 images**, while the included standalone `REMNET_split_summary.json` reports **454 final test images after its own filtering**. These are different recorded split artifacts, and must not be assumed equivalent. |
| V2 — external screened cohort | [Garbage Classification V2 (Kaggle)](https://www.kaggle.com/datasets/sumn2u/garbage-classification-v2), **version 12** | `/kaggle/input/datasets/sumn2u/garbage-classification-v2` | 10 source classes; six mapped classes; overlap/pHash screening yields **4,931** retained images. Common-source provenance with D1 may remain despite screening. The archived audit records an unresolved license discrepancy: Kaggle notice **MIT** vs creator site **CC BY-SA 4.0**. Check source terms before distributing images. |
| D3 — RealWaste external cohort | [Official RealWaste dataset (UCI)](https://archive.ics.uci.edu/dataset/908/realwaste) ([DOI](https://doi.org/10.24432/C5SS4G)); [mounted Kaggle mirror](https://www.kaggle.com/datasets/akash264208/real-waste) | `/kaggle/input/datasets/akash264208/real-waste` | UCI source license recorded as **CC BY 4.0**; mirror revision not verified. Map *Miscellaneous Trash* to *trash*. The locked six-class cohort contains **3,497** images after conservative screening. |

**Class order:** `cardboard`, `glass`, `metal`, `paper`, `plastic`, `trash`. For D3, confirm the recorded mapping CSV before inference. Attach the original image datasets and use the **existing audited manifest**, not a new convenience split or an arbitrary sample of images.

Dataset provenance files are included alongside the verification notebooks:
- `Garbage Classification V2 external validation/07_Garbage_Classification_V2/Dataset verification/Section2_Source_License_Citation_Version_Download_Details.json`
- `RealWaste external validation/08_RealWaste/Dataset verification/D3_Section2_Source_License_Citation_Version_Download_Details.json`

### Kaggle preparation

1. Create a Kaggle notebook with a GPU (Tesla T4 was recorded for inference measurements) when running deep-learning notebooks; CPU is sufficient for most audits and summary statistics.
2. Add the original Kaggle dataset to **Input**. For V2 also add `sumn2u/garbage-classification-v2` revision 12 or allow `kagglehub` to fetch it. For D3 attach the RealWaste Kaggle mirror, or stage the officially downloaded UCI images in the exact class-root layout expected by the code.
3. Supply the **separate, private** checkpoint/manifest dataset needed by zero-shot notebooks; the source archive does not contain these `.pt` weights. V2/D3 **classification** notebooks expect `/kaggle/input/datasets/akash264208/checkpoint-manifist`, with `Classification_checkpoints`, `manifist`, and `per_seed_performance_summary` discoverable beneath it. D3 **sustainability** notebooks instead use `/kaggle/input/datasets/akash264208/manifist-part2/Section3` and its `manifist` subdirectory. Confirm these inputs are present before running. The two roots are **not automatically interchangeable**.
4. Install dependencies (Kaggle notebooks may already include them): `python -m pip install -r requirements.txt`. For PyTorch CUDA wheels, use a platform-specific compatible build, ideally the recorded Kaggle environment; see version notes below. Kaggle installs may be notebook-local.
5. Run each notebook **top to bottom** in its intended Kaggle environment. Files and figures are written under `/kaggle/working/`; download the generated reports/CSVs/ZIPs at the end of a run. The notebooks embed their own paths and constants: **editing `config.yaml` alone will not change them**.

## How to run each notebook

Run the following notebooks separately. These paths are relative to `final_code/` and are case-sensitive on Linux/Kaggle.

### A. Original-dataset (D1) workflow

**Source-data audit (optional, no training):**

```bash
python "REMNET/06_Dataset_Preparation/remnet_dataset_audit.py" \
  /kaggle/input/datasets/saumyamohandas/garbage-classification-image-dataset \
  /kaggle/working/REMNET_dataset_audit
```

The script's filtering/split decisions can differ from the historical 463-image evaluation split. Preserve original manifests and reconcile the cohort counts before using the audit outputs to reproduce published figures. The historical evaluation notebooks may rely on an external original split manifest that is not included in this ZIP.

| Notebook (open in Kaggle and **Run all**) | Purpose |
|---|---|
| [`REMNET/01_Classification_Implementation/Efficientnet_lite0_accu.ipynb`](<REMNET/01_Classification_Implementation/Efficientnet_lite0_accu.ipynb>) | Train/evaluate standalone EfficientNet-Lite0 on D1. |
| [`REMNET/01_Classification_Implementation/MobileNet_Accu_s2.ipynb`](<REMNET/01_Classification_Implementation/MobileNet_Accu_s2.ipynb>) | Train/evaluate standalone MobileNetV2 on D1. |
| [`REMNET/01_Classification_Implementation/Resnet_50_Acc_s2.ipynb`](<REMNET/01_Classification_Implementation/Resnet_50_Acc_s2.ipynb>) | Train/evaluate standalone ResNet50 on D1. |
| [`REMNET/01_Classification_Implementation/Remnet_Accu_s2.ipynb`](<REMNET/01_Classification_Implementation/Remnet_Accu_s2.ipynb>) | Train/evaluate REMNET's three CNN constituents and ensemble on D1. |
| [`REMNET/02_Energy_and_Carbon_Measurement/efficientnet-lite-prob-co2-s2.ipynb`](<REMNET/02_Energy_and_Carbon_Measurement/efficientnet-lite-prob-co2-s2.ipynb>) | **Separate** EfficientNet-Lite0 training/inference and CodeCarbon tracking. |
| [`REMNET/02_Energy_and_Carbon_Measurement/mobilenet-v2-prob-c02-s2.ipynb`](<REMNET/02_Energy_and_Carbon_Measurement/mobilenet-v2-prob-c02-s2.ipynb>) | **Separate** MobileNetV2 training/inference and CodeCarbon tracking. |
| [`REMNET/02_Energy_and_Carbon_Measurement/resnet-50-prob-co2-s2.ipynb`](<REMNET/02_Energy_and_Carbon_Measurement/resnet-50-prob-co2-s2.ipynb>) | **Separate** ResNet50 training/inference and CodeCarbon tracking. |
| [`REMNET/02_Energy_and_Carbon_Measurement/remnet-co2-prob-s2.ipynb`](<REMNET/02_Energy_and_Carbon_Measurement/remnet-co2-prob-s2.ipynb>) | **Separate** REMNET constituent training and ensemble inference tracking; the ensemble's training total should count each constituent training log once. |
| [`REMNET/03_Statistical_Analysis/REMNET_Classification_Paired_T_Test_Stage2.ipynb`](<REMNET/03_Statistical_Analysis/REMNET_Classification_Paired_T_Test_Stage2.ipynb>) | Analyze saved five-seed D1 classification measurements; inspect embedded paths and values first. |
| [`REMNET/03_Statistical_Analysis/REMNET_Sustainability_Paired_T_Test_Stage2.ipynb`](<REMNET/03_Statistical_Analysis/REMNET_Sustainability_Paired_T_Test_Stage2.ipynb>) | Analyze separately recorded energy/carbon measurements; do not treat these as weight-matched classification runs. |
| [`REMNET/05_Computational_Complexity/Gflops.ipynb`](<REMNET/05_Computational_Complexity/Gflops.ipynb>) | Profile convolution/linear FLOPs at the notebook's chosen resolution and profiling convention. |
| [`REMNET/05_Computational_Complexity/throughput.ipynb`](<REMNET/05_Computational_Complexity/throughput.ipynb>) | Benchmark **randomly initialized** architectures (no checkpoints), using batch-1 latency and batch-32 throughput/memory. It is **not** a measured deployment profile of trained weights. |

**Seeds** used in the five-seed evaluations: `7, 49, 112, 345, 476`. The original Stage 2 classification and carbon notebooks resize inputs to **32 × 32**. For emissions, retain *native CodeCarbon* CO₂e separately from fixed-factor `energy (kWh) × 0.475 kg CO₂e/kWh` values.

### B. Garbage Classification V2 external evaluation

1. [`Dataset verification/stage2_part1.ipynb`](<Garbage Classification V2 external validation/07_Garbage_Classification_V2/Dataset verification/stage2_part1.ipynb>) — discover/download D1 and V2 sources and inventory classes.
2. [`Dataset verification/s3p2.ipynb`](<Garbage Classification V2 external validation/07_Garbage_Classification_V2/Dataset verification/s3p2.ipynb>) — screen exact overlaps and conservative near-duplicates; produce/verify the **4,931-image** six-class manifest. Use the frozen included manifest for reproducibility.
3. With the **classification** checkpoints attached, run all four independent inference notebooks (no retraining/fine-tuning):
   - [`efficientnetlite0.ipynb`](<Garbage Classification V2 external validation/07_Garbage_Classification_V2/Classification implementation/efficientnetlite0.ipynb>)
   - [`mobilenet-v2.ipynb`](<Garbage Classification V2 external validation/07_Garbage_Classification_V2/Classification implementation/mobilenet-v2.ipynb>)
   - [`resnet-50.ipynb`](<Garbage Classification V2 external validation/07_Garbage_Classification_V2/Classification implementation/resnet-50.ipynb>)
   - [`remnet123.ipynb`](<Garbage Classification V2 external validation/07_Garbage_Classification_V2/Classification implementation/remnet123.ipynb>)
4. [`classification-test.ipynb`](<Garbage Classification V2 external validation/07_Garbage_Classification_V2/Classification implementation/classification-test.ipynb>) — run the saved statistical-analysis template after confirming its input table corresponds to the produced V2 five-seed outputs.

**Note:** V2 screening eliminates identified image overlaps but does not prove independently collected image provenance. License notices conflict in the archive; consult the current dataset author before redistribution.

### C. RealWaste D3 external evaluation

1. [`Dataset verification/d3-s2.ipynb`](<RealWaste external validation/08_RealWaste/Dataset verification/d3-s2.ipynb>) — verify source, label mapping, D1 overlap checks, and the locked **3,497-image** manifest. The audit conservatively withholds flagged pHash candidates; it does not claim human near-duplicate adjudication.
2. With **classification** checkpoint inputs attached, run the four frozen model evaluations:
   - [`efficientnetlite0-class-d3.ipynb`](<RealWaste external validation/08_RealWaste/Classification implementation/efficientnetlite0-class-d3.ipynb>)
   - [`mobilenet-class-d3.ipynb`](<RealWaste external validation/08_RealWaste/Classification implementation/mobilenet-class-d3.ipynb>)
   - [`resnet50-class-d3.ipynb`](<RealWaste external validation/08_RealWaste/Classification implementation/resnet50-class-d3.ipynb>)
   - [`remnet-class-d3.ipynb`](<RealWaste external validation/08_RealWaste/Classification implementation/remnet-class-d3.ipynb>)
3. [`class_test.ipynb`](<RealWaste external validation/08_RealWaste/Classification implementation/class_test.ipynb>) — run saved D3 classification statistical analysis; verify embedded input values against exported CSVs.
4. In **separate** Kaggle sessions with the **sustainability** checkpoint/manifest mount, run the four independently monitored D3 inference notebooks:
   - [`efficient-co2-d3.ipynb`](<RealWaste external validation/08_RealWaste/Sustainability implementation/efficient-co2-d3.ipynb>)
   - [`mobilenetv2-co2-d3.ipynb`](<RealWaste external validation/08_RealWaste/Sustainability implementation/mobilenetv2-co2-d3.ipynb>)
   - [`resnet-50-co2-d3.ipynb`](<RealWaste external validation/08_RealWaste/Sustainability implementation/resnet-50-co2-d3.ipynb>)
   - [`remnet-sustainable-d3.ipynb`](<RealWaste external validation/08_RealWaste/Sustainability implementation/remnet-sustainable-d3.ipynb>)

D3 classification and sustainability each resize to the same input size **for a given model**: EfficientNet-Lite0 and MobileNetV2 **384 × 384**, ResNet50 **350 × 350**, REMNET **484 × 484**. This is **not** the 32 × 32 Stage 2 training/monitoring size. The D3 sustainability sessions use 2 passes × 3,497 images = **6,994 processed images per seed**; they measure inference (not training) energy. Check for prediction/accuracy discrepancies between the separately executed classifications and sustainability diagnostics before making a combined performance–energy claim.

## Recorded dependency environment

Observed in executed notebook outputs and JSON audit metadata, rather than inferred from the current machine:

| Component | Version recorded in this archive | Provenance |
|---|---|---|
| Python | **3.13.18** | D3 dataset-verification JSON |
| PyTorch | **2.11.0+cu130** | executed D3 notebooks |
| torchvision | **0.26.0+cu130** | executed ResNet50 and throughput notebooks |
| timm | **1.0.30** | executed D3 notebooks |
| CodeCarbon | **3.3.2** | installation command and executed D3 sustainability notebooks |
| kagglehub | **1.0.3** | executed D3 ResNet50 notebook |
| numpy | **2.1.3** | D3 dataset-verification JSON |
| pandas | **2.3.3** | D3 dataset-verification JSON |
| Pillow | **13.0.0** | D3 dataset-verification JSON (`PIL`) |

Other modules appear in notebook imports, but **their exact installed versions are not captured consistently** in the supplied archive: `scipy`, `scikit-learn`, `matplotlib`, `python-docx`, `scikit-image`, `opencv-python` (`cv2`), `transformers`, and `IPython`. `requirements.txt` therefore uses **declared compatibility ranges** for those entries instead of inventing an "actual" pinned version. For strict bitwise reproduction, export `python -m pip freeze > run-specific-freeze.txt` plus CUDA/GPU/driver details from each original Kaggle environment. Some notebooks themselves invoke `pip install` without version pins and may change the environment during execution.

**PyTorch wheel caution:** `torch==2.11.0` and `torchvision==0.26.0` in `requirements.txt` pin the recorded upstream versions but not the local `+cu130` CUDA build. Kaggle's existing GPU runtime or a matching platform-specific PyTorch wheel index is required to reproduce the CUDA builds and performance characteristics.

## Shared code, modules and reproducibility

- The **only standalone repository Python module** is [`REMNET/06_Dataset_Preparation/remnet_dataset_audit.py`](<REMNET/06_Dataset_Preparation/remnet_dataset_audit.py>). It uses standard-library imports, runs directly with the command above, and is **included** in the repository.
- Notebook-source inspection found **no imports of additional user-defined `.py` modules**. Training, evaluation and sustainability helper functions are defined inside the notebooks. External import dependencies are listed in `requirements.txt` (plus Python standard library).
- `config.yaml` records dataset links, the actual archive paths, split sizes, seeds and reporting conventions. It is provided for documentation/repository integration only; **notebooks do not parse it**. To change paths in existing notebooks, edit their own input-root/manifest variables.
- Data-source and per-seed sustainability reports are included, e.g. [`09_Sustainability_Results/REMNET_Sustainability_Five_Seed_Source_Data(1).csv`](<09_Sustainability_Results/REMNET_Sustainability_Five_Seed_Source_Data(1).csv>). These distinguish **CodeCarbon original** emissions from **standardized fixed-factor** CO₂e.
- No original image files or trained checkpoints have been packaged here. Re-running the frozen external tests requires compatible externally supplied weights, class order and manifests. Do **not** tune frozen models against V2 or D3 if claiming zero-shot evaluation.

## Citation and rights

Cite the original dataset and RealWaste as described in their linked source metadata. V2 source/citation information and unresolved licensing notes are preserved in its verification JSON. This repository's `LICENSE` deliberately **does not grant an open-source license** because no named copyright owner or permission to relicense the contributed code was provided. Dataset images, model weights, pretrained weights and third-party libraries are governed by **their own** terms and are **not** relicensed by this repository notice. Maintainers may replace the code-rights notice with a chosen SPDX-recognized license upon authorization from the rights holder(s).
